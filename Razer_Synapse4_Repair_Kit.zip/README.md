
# Razer Synapse 4 Repair Kit

This package is designed to help fix Razer Synapse 4 not launching properly on a specific Windows user profile. It includes tools to clean up corrupted configuration files, reset user-specific registry settings, and relaunch Synapse with a clean state.

## Contents

- `FixSynapse.cmd`: Clears Razer's user cache and WebView2 data, then attempts to start Synapse.
- `RazerProfileFix.reg`: Resets broken registry entries that may block Synapse from launching.
- `README.md`: This file.

## Usage Instructions

### 1. Run the Registry Fix

1. Double-click `RazerProfileFix.reg`
2. Accept all prompts to apply the registry changes
3. Restart your computer

### 2. Run the Cleanup Script

1. Right-click `FixSynapse.cmd` and choose **Run as administrator**
2. Wait for the script to complete
3. If Synapse does not launch, check `synapse_log.txt` on your desktop for output

## Notes

- This fix is only for **Razer Synapse 4**
- It is safe to run multiple times
- Always restart your system after applying registry changes

---

Created by ChatGPT in collaboration with the user (2025)
